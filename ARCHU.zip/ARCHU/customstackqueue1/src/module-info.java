/**
 * 
 */
/**
 * 
 */
module customstackqueue1 {
}
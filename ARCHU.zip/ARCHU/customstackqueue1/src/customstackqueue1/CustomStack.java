package customstackqueue1;
import java.util.ArrayList;
  public class CustomStack {
	
    private ArrayList<Integer> stack;

	    public CustomStack() {
	        stack = new ArrayList<>();
	    }

	    public void Push(int value) {
	        stack.add(value);
	    }

	    public int Pop() {
	        if (IsEmpty()) {
	            throw new IllegalStateException("Stack is empty");
	        }
	        int value = stack.get(stack.size() - 1);
	        stack.remove(stack.size() - 1);
	        return value;
	    }

	    public int Peek() {
	        if (IsEmpty()) {
	            throw new IllegalStateException("Stack is empty");
	        }
	        return stack.get(stack.size() - 1);
	    }

	    public boolean IsEmpty() {
	        return stack.isEmpty();
	    }
	}

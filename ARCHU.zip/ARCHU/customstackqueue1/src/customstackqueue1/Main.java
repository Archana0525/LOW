package customstackqueue1;

public class Main {

	public static void main(String[] args) {
		
		        CustomStack stack = new CustomStack();

		        // Pushing integers onto the stack
		        stack.Push(8);
		        stack.Push(16);
		        stack.Push(24);

		        // Popping and displaying integers until the stack is empty
		        while (!stack.IsEmpty()) {
		            System.out.println("Popped: " + stack.Pop());
		        }
	}   
		
}
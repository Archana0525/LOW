/**
 * 
 */
/**
 * 
 */
module stringoperation {
}
/**
 * 
 */
/**
 * 
 */
module basiccalculator {
}
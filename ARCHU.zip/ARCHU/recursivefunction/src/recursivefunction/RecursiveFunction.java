package recursivefunction;
public class RecursiveFunction { 
	 public static void main(String[] args) {
	int[] array = {1,3,5,7,9};
    int sum = SumArray(array, 0);
   System.out.println("Sum of array elements: " + sum);
} 


public static int SumArray(int[] arr, int index) {
	
if (index == arr.length) {
    return 0;
}

return arr[index] + SumArray(arr, index + 1);
}
}
package stackdemo;
interface Stack {
    void push(int element);
    int pop();
    int peek();
    boolean isEmpty();
}

class CustomStack implements Stack {
    private int[] stackArray;
    private int top;

    public CustomStack(int capacity) {
        stackArray = new int[capacity];
        top = -1;
    }

    @Override
    public void push(int element) {
        if (top == stackArray.length - 1) {
            System.out.println("Stack Overflow");
            return;
        }
        stackArray[++top] = element;
    }

    @Override
    public int pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stackArray[top--];
    }

    @Override
    public int peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stackArray[top];
    }

    @Override
    public boolean isEmpty() {
        return (top == -1);
    }
}

public class Stackdemo {
    public static void main(String[] args) {
        Stack stack = new CustomStack(5);

        // Pushing integers onto the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        // Popping and displaying integers until the stack is empty
        while (!stack.isEmpty()) {
            System.out.println("Popped: " + stack.pop());
        }
    }
}
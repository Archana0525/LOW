/**
 * 
 */
/**
 * 
 */
module customstackqueue {
}
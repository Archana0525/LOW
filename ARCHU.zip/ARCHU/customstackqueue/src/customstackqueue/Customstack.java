package customstackqueue;
import java.util.LinkedList;

public class Customstack<T> {
    private LinkedList<T> queue;

    public Customstack() {
        queue = new LinkedList<>();
    }

    public void Enqueue(T value) {
        queue.addLast(value);
    }

    public T Dequeue() {
        if (IsEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return queue.removeFirst();
    }

    public T Peek() {
        if (IsEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        return queue.getFirst();
    }

    public boolean IsEmpty() {
        return queue.isEmpty();
    }
}
